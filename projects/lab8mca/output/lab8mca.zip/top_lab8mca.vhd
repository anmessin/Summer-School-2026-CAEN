----------------------------------------------------------------------------------
-- Company: 	Nuclear Instruments SRL
-- Engineer: 	Andrea Abba
-- 
-- Create Date: 07.06.2020 10:24:18
-- Design Name: SciDK Scicompiler Development Kit
-- Module Name: TOP_lab8mca
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
-- http://www.nuclearinstruments.eu
-- Nuclear Instruments SRL, via lecco 16, Lambrugo (CO), ITALY
-- info@nuclearinstruments.eu
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use ieee.std_logic_misc.all;
use ieee.math_real.all;
library UNISIM;
use UNISIM.VComponents.all;

Library xpm;
use xpm.vcomponents.all;
    
entity TOP_lab8mca is
    Port (  
		    
			
			--input clock
			clk_100 : in STD_LOGIC;
			
			--adc
			ADC_A_IN : in STD_LOGIC_VECTOR (13 downto 0);
			ADC_B_IN : in STD_LOGIC_VECTOR (13 downto 0);
			CLK_TO_ADC_A : out std_logic;
			OE_ADC_A : out std_logic;
			SHND_ADC_A : out std_logic;
			CLK_TO_ADC_B : out std_logic;
			OE_ADC_B : out std_logic;
			SHND_ADC_B : out std_logic;
			
			--USB Interface
			FTDI_ADBUS : inout STD_LOGIC_VECTOR ( 7 downto 0 );
			FTDI_CLK : in STD_LOGIC;
			FTDI_OEN : out STD_LOGIC;
			FTDI_RDN : out STD_LOGIC;
			FTDI_RXFN : in STD_LOGIC;
			FTDI_SIWU : out STD_LOGIC;
			FTDI_TXEN : in STD_LOGIC;
			FTDI_TXN : out STD_LOGIC;
			
			--gpio
			led_0 : out STD_LOGIC_VECTOR(0 downto 0);
			led_1 : out STD_LOGIC_VECTOR(0 downto 0);
					
			gpio : inout STD_LOGIC_VECTOR ( 7 downto 0 );
			sw1 : in std_logic;
        
			--digital lemo
			lemo_a : inout STD_LOGIC;
			lemo_b : inout STD_LOGIC;
			lemo_dir_a : out STD_LOGIC;
			lemo_dir_b : out STD_LOGIC;
			lemo_oe : out STD_LOGIC;
        
			--boot switch
			boot_sw : in std_logic;
			boot_led : out STD_LOGIC;
        
			--i2c master
			IIC_0_scl : inout std_logic;
			IIC_0_sda : inout std_logic;
		
			  
			--security eeprom			  
			EEMOSI : out STD_LOGIC;
			EEMISO : in STD_LOGIC;
			EECLK : out STD_LOGIC;
			EECS : out STD_LOGIC
                              
                              
			  ); 
end TOP_lab8mca;

architecture Behavioral of TOP_lab8mca is
	attribute keep : string;     
	
	
	 component main_clk_gen 
    port
     ( 
        sample_clk : out std_logic;
        locked  : out std_logic;
        clk_in1 : in std_logic;
        clk_out2 : out std_logic
     );
     END COMPONENT;
	 
    COMPONENT ftdi245_cdc
    PORT(
        FTDI_RXFN : IN std_logic;
        FTDI_TXEN : IN std_logic;
        FTDI_CLK : IN std_logic;
        f_CLK : IN std_logic;
        f_RESET : IN std_logic;
        FTDI_ADBUS : INOUT std_logic_vector(7 downto 0);      
        FTDI_RDN : OUT std_logic;
        FTDI_TXN : OUT std_logic;
        FTDI_OEN : OUT std_logic;
        FTDI_SIWU : OUT std_logic;
		
	    EEMOSI : out STD_LOGIC;
        EEMISO : in STD_LOGIC;
        EECLK : out STD_LOGIC;
        EECS : out STD_LOGIC;
		
		-- Register interface          
			BUS_Spectrum_0_READ_ADDRESS : OUT STD_LOGIC_VECTOR(15 downto 0); 
	BUS_Spectrum_0_READ_DATA : IN STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Spectrum_0_WRITE_DATA : OUT STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Spectrum_0_W_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Spectrum_0_R_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Spectrum_0_VLD : IN STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_STATUS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_STATUS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_CONFIG_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_0_CONFIG_LIMIT_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_CONFIG_LIMIT_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_LIMIT_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_0_CONFIG_REBIN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_CONFIG_REBIN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_REBIN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_0_CONFIG_MIN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_CONFIG_MIN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_MIN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_0_CONFIG_MAX_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_0_CONFIG_MAX_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_0_CONFIG_MAX_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_OFFSET_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_OFFSET_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_OFFSET_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_OFFSET_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_THRS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_THRS_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_THRS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_THRS_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_TRIG_K_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRIG_K_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_TRIG_K_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_TRIG_K_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_TRIG_M_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRIG_M_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_TRIG_M_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_TRIG_M_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_TRAP_K_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRAP_K_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_TRAP_K_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_TRAP_K_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_DECONV_M_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_DECONV_M_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_DECONV_M_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_DECONV_M_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_TRAP_GAIN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRAP_GAIN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_TRAP_GAIN_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_TRAP_GAIN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_BL_LEN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_BL_LEN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_BL_LEN_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_BL_LEN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_BL_INIB_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_BL_INIB_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_BL_INIB_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_BL_INIB_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_SAMPLE_POS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_SAMPLE_POS_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_SAMPLE_POS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_SAMPLE_POS_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_T_RUN_CFG_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_RUN_CFG_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_RUN_CFG_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_RUN_CFG_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Oscilloscope_0_READ_ADDRESS : OUT STD_LOGIC_VECTOR(13 downto 0); 
	BUS_Oscilloscope_0_READ_DATA : IN STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Oscilloscope_0_WRITE_DATA : OUT STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Oscilloscope_0_W_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Oscilloscope_0_R_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Oscilloscope_0_VLD : IN STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_READ_STATUS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_READ_STATUS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_READ_POSITION_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_READ_POSITION_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_CONFIG_PRETRIGGER_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_PRETRIGGER_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Oscilloscope_0_CONFIG_ARM_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_CONFIG_ARM_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_ARM_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Oscilloscope_0_CONFIG_DECIMATOR_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Oscilloscope_0_CONFIG_DECIMATOR_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Oscilloscope_0_CONFIG_DECIMATOR_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRAP_M_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_T_TRAP_M_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_T_TRAP_M_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_T_TRAP_M_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_LENGTH_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_LENGTH_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_LENGTH_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_LENGTH_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_DLENGTH_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_DLENGTH_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_DLENGTH_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_DLENGTH_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Spectrum_1_READ_ADDRESS : OUT STD_LOGIC_VECTOR(15 downto 0); 
	BUS_Spectrum_1_READ_DATA : IN STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Spectrum_1_WRITE_DATA : OUT STD_LOGIC_VECTOR(31 downto 0); 
	BUS_Spectrum_1_W_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Spectrum_1_R_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
	BUS_Spectrum_1_VLD : IN STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_STATUS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_STATUS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_CONFIG_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_1_CONFIG_LIMIT_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_CONFIG_LIMIT_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_LIMIT_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_1_CONFIG_REBIN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_CONFIG_REBIN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_REBIN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_1_CONFIG_MIN_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_CONFIG_MIN_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_MIN_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_Spectrum_1_CONFIG_MAX_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_Spectrum_1_CONFIG_MAX_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_Spectrum_1_CONFIG_MAX_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_MODE_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_MODE_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_MODE_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_MODE_WR : OUT STD_LOGIC_VECTOR(0 downto 0); 
		REG_UNIQUE_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_UNIQUE_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
	

        
		REG_FIRMWARE_BUILD : IN STD_LOGIC_VECTOR(31 downto 0);
        
        
        REG_OFFSET_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
        REG_OFFSET_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
        INT_OFFSET_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
        INT_OFFSET_WR : OUT STD_LOGIC_VECTOR(0 downto 0);

        REG_IO_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
        REG_IO_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
        INT_IO_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
        INT_IO_WR : OUT STD_LOGIC_VECTOR(0 downto 0);
        
		--FLASH CONTROLLER   
		BUS_Flash_0_READ_DATA : IN STD_LOGIC_VECTOR(31 downto 0);
		BUS_Flash_0_ADDRESS : OUT STD_LOGIC_VECTOR(15 downto 0); 
		BUS_Flash_0_WRITE_DATA : OUT STD_LOGIC_VECTOR(31 downto 0); 
		BUS_Flash_0_W_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
		BUS_Flash_0_R_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
		BUS_Flash_0_VLD : IN STD_LOGIC_VECTOR(0 downto 0); 

		REG_FLASH_CNTR_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_FLASH_CNTR_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_FLASH_CNTR_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_FLASH_CNTR_WR : OUT STD_LOGIC_VECTOR(0 downto 0);               

		REG_FLASH_ADDRESS_RD : IN STD_LOGIC_VECTOR(31 downto 0); 
		REG_FLASH_ADDRESS_WR : OUT STD_LOGIC_VECTOR(31 downto 0); 
		INT_FLASH_ADDRESS_RD : OUT STD_LOGIC_VECTOR(0 downto 0); 
		INT_FLASH_ADDRESS_WR : OUT STD_LOGIC_VECTOR(0 downto 0);     


		--test
		BUS_Test_0_READ_DATA : IN STD_LOGIC_VECTOR(31 downto 0);
		BUS_Test_0_ADDRESS : OUT STD_LOGIC_VECTOR(15 downto 0); 
		BUS_Test_0_WRITE_DATA : OUT STD_LOGIC_VECTOR(31 downto 0); 
		BUS_Test_0_W_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
		BUS_Test_0_R_INT : OUT STD_LOGIC_VECTOR(0 downto 0); 
		BUS_Test_0_VLD : IN STD_LOGIC_VECTOR(0 downto 0)		
        );
    END COMPONENT;
    
    
    COMPONENT scidk_internal_i2c_manager is
    Port ( clk : in STD_LOGIC;
           reset : in STD_LOGIC;
           offset : in STD_LOGIC_VECTOR (15 downto 0);
           w_offset : in STD_LOGIC;
           sda : inout STD_LOGIC;
           scl : inout STD_LOGIC
           );
    end COMPONENT;

    

    signal sample_clk : std_logic;
    signal async_clk : std_logic_vector (0 downto 0) := "0";
    signal GlobalClock : std_logic_vector (0 downto 0) := "0";
    signal BUS_CLK : std_logic_vector (0 downto 0) := "0";
    signal GlobalReset : std_logic_vector (0 downto 0) := "0";       
	signal CLK_ACQ : std_logic_vector (0 downto 0) := "0";
	
    signal mcg_lock : std_logic;
    signal REG_OFFSET :  STD_LOGIC_VECTOR(31 downto 0); 
    signal REG_OFFSET_WR :  STD_LOGIC_VECTOR(0 downto 0); 
    
    signal REG_IO_RD : STD_LOGIC_VECTOR(31 downto 0); 
    signal REG_IO_WR : STD_LOGIC_VECTOR(31 downto 0); 
    
	signal BUS_Flash_0_READ_DATA :  STD_LOGIC_VECTOR(31 downto 0);
    signal BUS_Flash_0_ADDRESS :  STD_LOGIC_VECTOR(15 downto 0); 
    signal BUS_Flash_0_WRITE_DATA :  STD_LOGIC_VECTOR(31 downto 0); 
    signal BUS_Flash_0_W_INT :  STD_LOGIC_VECTOR(0 downto 0); 
    signal BUS_Flash_0_R_INT :  STD_LOGIC_VECTOR(0 downto 0); 
    signal BUS_Flash_0_VLD :  STD_LOGIC_VECTOR(0 downto 0);   
    
    signal REG_FLASH_CNTR_RD :  STD_LOGIC_VECTOR(31 downto 0); 
    signal REG_FLASH_CNTR_WR :  STD_LOGIC_VECTOR(31 downto 0); 
    signal INT_FLASH_CNTR_RD :  STD_LOGIC_VECTOR(0 downto 0); 
    signal INT_FLASH_CNTR_WR :  STD_LOGIC_VECTOR(0 downto 0); 
    
    signal REG_FLASH_ADDRESS_RD :  STD_LOGIC_VECTOR(31 downto 0); 
    signal REG_FLASH_ADDRESS_WR :  STD_LOGIC_VECTOR(31 downto 0); 
    signal INT_FLASH_ADDRESS_RD :  STD_LOGIC_VECTOR(0 downto 0); 
    signal INT_FLASH_ADDRESS_WR :  STD_LOGIC_VECTOR(0 downto 0);         
    
	signal BUS_Test_0_READ_DATA :  STD_LOGIC_VECTOR(31 downto 0);
    signal BUS_Test_0_ADDRESS :  STD_LOGIC_VECTOR(15 downto 0); 
    signal BUS_Test_0_WRITE_DATA :  STD_LOGIC_VECTOR(31 downto 0); 
    signal BUS_Test_0_W_INT :  STD_LOGIC_VECTOR(0 downto 0); 
    signal BUS_Test_0_R_INT :  STD_LOGIC_VECTOR(0 downto 0); 
    signal BUS_Test_0_VLD :  STD_LOGIC_VECTOR(0 downto 0) := "1";  	
	
	signal LEMO_0_A_OUT : std_logic_vector(0 downto 0);
    signal LEMO_0_A_IN : std_logic_vector(0 downto 0);
	signal LEMO_1_A_OUT : std_logic_vector(0 downto 0);
    signal LEMO_1_A_IN : std_logic_vector(0 downto 0);

    signal LEMO_0_DIRECTION : std_logic_vector(0 downto 0) := "0";
    signal LEMO_1_DIRECTION : std_logic_vector(0 downto 0) := "0";

    signal CLK_40 :  std_logic_vector(0 downto 0); 
	signal CLK_80 : std_logic_vector(0 downto 0); 
    signal CLK_160 :  std_logic_vector(0 downto 0);   
    signal CLK_320 : std_logic_vector(0 downto 0); 
	signal CLK_125 : std_logic_vector(0 downto 0);
	signal FAST_CLK_100 : std_logic_vector (0 downto 0) := "0";
	signal FAST_CLK_200 : std_logic_vector (0 downto 0) := "0";
	signal FAST_CLK_250 : std_logic_vector (0 downto 0) := "0";
	signal FAST_CLK_250_90 : std_logic_vector (0 downto 0) := "0";
	signal FAST_CLK_500 : std_logic_vector (0 downto 0) := "0";
	signal FAST_CLK_500_90 : std_logic_vector (0 downto 0) := "0";
	
	signal CHA0 : STD_LOGIC_VECTOR (13 downto 0);
	signal CHA1 : STD_LOGIC_VECTOR (13 downto 0);

	signal pw_led_counter : integer :=0;
	signal power_led_sig : std_logic := '1';


	COMPONENT CLK_125MHZ
	PORT (
	clk_out1 : OUT STD_LOGIC;
	clk_in1  : IN  STD_LOGIC
	);
	END COMPONENT;

	
		signal U0_DATA_OUT : STD_LOGIC_VECTOR(15 DOWNTO 0);
	signal U0_ENERGY : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal U0_ENERGY_STROBE : STD_LOGIC_VECTOR(0 downto 0) := "0";
	signal U0_TRIGGER_OUT : STD_LOGIC_VECTOR(0 downto 0) := "0";
	signal U0_BASELINE_HOLD : STD_LOGIC_VECTOR(0 downto 0) := "0";
	signal U0_TRIGGER_DELTA_MON : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal U0_TRIGGER_TRAP_MON : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal U0_TRAP_MON : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal U0_TRAP_BL_MON : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal U0_BL_MON : STD_LOGIC_VECTOR(31 DOWNTO 0);

	COMPONENT mcahp_test_KHCTRIYF
		PORT( 
			adc_data : in STD_LOGIC_VECTOR(15 downto 0);
			positive_r : in STD_LOGIC;
			digital_offset : in STD_LOGIC_VECTOR(15 downto 0);
			threshold : in STD_LOGIC_VECTOR(31 downto 0);
			trig_k : in STD_LOGIC_VECTOR(15 downto 0);
			trig_m : in STD_LOGIC_VECTOR(15 downto 0);
			e_k : in STD_LOGIC_VECTOR(15 downto 0);
			e_m : in STD_LOGIC_VECTOR(15 downto 0);
			e_MDec : in STD_LOGIC_VECTOR(23 downto 0);
			e_G : in STD_LOGIC_VECTOR(23 downto 0);
			baseline_len : in STD_LOGIC_VECTOR(3 downto 0);
			baseline_inib : in STD_LOGIC_VECTOR(15 downto 0);
			e_sample_delay : in STD_LOGIC_VECTOR(15 downto 0);
			timetag : in STD_LOGIC_VECTOR(63 downto 0);
			run_cfg : in STD_LOGIC;
			tr_reset : in STD_LOGIC;
			gin : in STD_LOGIC;
			GIN_SELECT : in STD_LOGIC_VECTOR(3 downto 0);
			adc_data_out : out STD_LOGIC_VECTOR(15 downto 0);
			energy : out STD_LOGIC_VECTOR(31 downto 0);
			energy_strobe : out STD_LOGIC;
			trigger_sig : out STD_LOGIC;
			baseline_hold : out STD_LOGIC;
			trigger_delta_monitor : out STD_LOGIC_VECTOR(31 downto 0);
			trigger_trap_monitor : out STD_LOGIC_VECTOR(31 downto 0);
			trap : out STD_LOGIC_VECTOR(31 downto 0);
			trap_minus_baseline : out STD_LOGIC_VECTOR(31 downto 0);
			baseline_out : out STD_LOGIC_VECTOR(31 downto 0);
			timestamp : out STD_LOGIC_VECTOR(63 downto 0);
			tr_inhibit_trigger : out STD_LOGIC;
			ap_clk : in STD_LOGIC;
			ap_rst : in STD_LOGIC
		);
	END COMPONENT;

signal U1_A0 : std_logic_vector(15 downto 0);
signal U2_out_0 : std_logic_vector(15 downto 0);
signal U3_out_0 : std_logic_vector(31 downto 0);
signal U4_out_0 : std_logic_vector(15 downto 0);
signal U5_out_0 : std_logic_vector(15 downto 0);
signal U6_out_0 : std_logic_vector(23 downto 0);
signal U7_out_0 : std_logic_vector(23 downto 0);
signal U8_out_0 : std_logic_vector(3 downto 0);
signal U9_out_0 : std_logic_vector(15 downto 0);
signal U10_out_0 : std_logic_vector(15 downto 0);
	signal BUS_Oscilloscope_0_READ_DATA : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal BUS_Oscilloscope_0_VLD : STD_LOGIC_VECTOR(0 DOWNTO 0);
	signal REG_Oscilloscope_0_READ_STATUS_RD : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal REG_Oscilloscope_0_READ_POSITION_RD : STD_LOGIC_VECTOR(31 DOWNTO 0);

	COMPONENT xlx_oscilloscope_sync
		GENERIC( 
			channels : INTEGER := 6;
			memLength : INTEGER := 2048;
			wordWidth : INTEGER := 28
		);
		PORT( 
			ANALOG : in STD_LOGIC_VECTOR((wordWidth*channels)-1 downto 0);
			D0 : in STD_LOGIC_VECTOR(channels-1 downto 0);
			D1 : in STD_LOGIC_VECTOR(channels-1 downto 0);
			D2 : in STD_LOGIC_VECTOR(channels-1 downto 0);
			D3 : in STD_LOGIC_VECTOR(channels-1 downto 0);
			TRIG : in STD_LOGIC_VECTOR(0 downto 0);
			BUSY : out STD_LOGIC_VECTOR(0 downto 0);
			CE : in STD_LOGIC_VECTOR(0 downto 0);
			CLK_WRITE : in STD_LOGIC_VECTOR(0 downto 0);
			RESET : in STD_LOGIC_VECTOR(0 downto 0);
			CLK_READ : in STD_LOGIC_VECTOR(0 downto 0);
			READ_ADDRESS : in STD_LOGIC_VECTOR(integer(ceil(log2(real(memLength*channels))))-1 downto 0);
			READ_DATA : out STD_LOGIC_VECTOR(31 downto 0);
			READ_DATAVALID : out STD_LOGIC_VECTOR(0 downto 0);
			READ_STATUS : out STD_LOGIC_VECTOR(31 downto 0);
			READ_POSITION : out STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_TRIGGER_MODE : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_TRIGGER_LEVEL : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_PRETRIGGER : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_DECIMATOR : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_ARM : in STD_LOGIC_VECTOR(31 downto 0)
		);
	END COMPONENT;

	signal U12_b : STD_LOGIC_VECTOR(27 DOWNTO 0);

	COMPONENT sigunsig
		GENERIC( 
			A_SIZE : INTEGER := 32;
			B_SIZE : INTEGER := 28;
			OPERATION : STRING := "sign_to_sign"
		);
		PORT( 
			a : in STD_LOGIC_VECTOR(A_SIZE-1 downto 0);
			b : out STD_LOGIC_VECTOR(B_SIZE-1 downto 0)
		);
	END COMPONENT;

	signal U13_b : STD_LOGIC_VECTOR(27 DOWNTO 0);
	signal U14_b : STD_LOGIC_VECTOR(27 DOWNTO 0);
	signal U15_b : STD_LOGIC_VECTOR(27 DOWNTO 0);
signal U16_out_0 : std_logic_vector(15 downto 0);
signal U17_CONST : STD_LOGIC_VECTOR(0 downto 0) := (others => '0');
signal U18_out_0 : std_logic_vector(0 downto 0);
signal U19_out_0 : std_logic_vector(15 downto 0);
	signal BUS_Spectrum_1_READ_DATA : STD_LOGIC_VECTOR(31 DOWNTO 0);
	signal BUS_Spectrum_1_VLD : STD_LOGIC_VECTOR(0 DOWNTO 0);
	signal REG_Spectrum_1_STATUS_RD : STD_LOGIC_VECTOR(31 DOWNTO 0);

	COMPONENT xlx_spectrum
		GENERIC( 
			memLength : INTEGER := 4096;
			wordWidth : INTEGER := 32;
			CLK_FREQ : INTEGER := 125000
		);
		PORT( 
			ENERGY : in STD_LOGIC_VECTOR(15 downto 0);
			ENERGY_STROBE : in STD_LOGIC_VECTOR(0 downto 0);
			P_running : out STD_LOGIC_VECTOR(0 downto 0);
			P_acceptedPulse : out STD_LOGIC_VECTOR(0 downto 0);
			CLK_WRITE : in STD_LOGIC_VECTOR(0 downto 0);
			CE : in STD_LOGIC_VECTOR(0 downto 0);
			RESET : in STD_LOGIC_VECTOR(0 downto 0);
			CLK_READ : in STD_LOGIC_VECTOR(0 downto 0);
			READ_ADDRESS : in STD_LOGIC_VECTOR(15 downto 0);
			READ_DATA : out STD_LOGIC_VECTOR(31 downto 0);
			READ_INT : in STD_LOGIC_VECTOR(0 downto 0);
			READ_DATAVALID : out STD_LOGIC_VECTOR(0 downto 0);
			STATUS : out STD_LOGIC_VECTOR(31 downto 0);
			CONFIG : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_LIMIT : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_REBIN : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_MIN : in STD_LOGIC_VECTOR(31 downto 0);
			CONFIG_MAX : in STD_LOGIC_VECTOR(31 downto 0)
		);
	END COMPONENT;

	signal U21_b : STD_LOGIC_VECTOR(27 DOWNTO 0);
	signal U22_b : STD_LOGIC_VECTOR(27 DOWNTO 0);
	signal U23_b : STD_LOGIC_VECTOR(15 DOWNTO 0);
signal U24_out_0 : std_logic_vector(31 downto 0);
signal U25_out_0 : std_logic_vector(31 downto 0);
	signal U26_EVENT_OUT : STD_LOGIC_VECTOR(15 DOWNTO 0);
	signal U26_DV_OUT : STD_LOGIC_VECTOR(0 downto 0) := "0";

	COMPONENT PileupRejector_PFPWEZES
		PORT( 
			data_in : in STD_LOGIC_VECTOR(15 downto 0);
			dv_in : in STD_LOGIC;
			pileup_inib_double : in STD_LOGIC_VECTOR(31 downto 0);
			pileup_inib : in STD_LOGIC_VECTOR(31 downto 0);
			mode : in STD_LOGIC_VECTOR(3 downto 0);
			prarallizable : in STD_LOGIC;
			rst_stat : in STD_LOGIC;
			ap_clk : in STD_LOGIC;
			ap_rst : in STD_LOGIC;
			data_out : out STD_LOGIC_VECTOR(15 downto 0);
			dv_out : out STD_LOGIC;
			inib : out STD_LOGIC;
			rej : out STD_LOGIC;
			drej : out STD_LOGIC;
			ic : out STD_LOGIC_VECTOR(31 downto 0);
			oc : out STD_LOGIC_VECTOR(31 downto 0);
			rejected : out STD_LOGIC_VECTOR(31 downto 0);
			rejected_double : out STD_LOGIC_VECTOR(31 downto 0)
		);
	END COMPONENT;

signal U27_out_0 : std_logic_vector(3 downto 0);
	signal BUS_Spectrum_0_READ_ADDRESS : STD_LOGIC_VECTOR(15 downto 0);
	signal BUS_Spectrum_0_READ_DATA : STD_LOGIC_VECTOR(31 downto 0);
	signal BUS_Spectrum_0_WRITE_DATA : STD_LOGIC_VECTOR(31 downto 0);
	signal BUS_Spectrum_0_W_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Spectrum_0_R_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Spectrum_0_VLD : STD_LOGIC_VECTOR(0 downto 0) := "1";
	signal REG_Spectrum_0_STATUS_RD : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_STATUS_RD : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_0_CONFIG_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_CONFIG_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_0_CONFIG_LIMIT_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_CONFIG_LIMIT_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_0_CONFIG_REBIN_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_CONFIG_REBIN_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_0_CONFIG_MIN_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_CONFIG_MIN_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_0_CONFIG_MAX_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_0_CONFIG_MAX_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Oscilloscope_0_READ_ADDRESS : STD_LOGIC_VECTOR(13 downto 0);
	signal BUS_Oscilloscope_0_WRITE_DATA : STD_LOGIC_VECTOR(31 downto 0);
	signal BUS_Oscilloscope_0_W_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Oscilloscope_0_R_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal INT_Oscilloscope_0_READ_STATUS_RD : STD_LOGIC_VECTOR(0 downto 0);
	signal INT_Oscilloscope_0_READ_POSITION_RD : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Oscilloscope_0_CONFIG_PRETRIGGER_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Oscilloscope_0_CONFIG_ARM_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Oscilloscope_0_CONFIG_ARM_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Oscilloscope_0_CONFIG_DECIMATOR_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Oscilloscope_0_CONFIG_DECIMATOR_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Spectrum_1_READ_ADDRESS : STD_LOGIC_VECTOR(15 downto 0);
	signal BUS_Spectrum_1_WRITE_DATA : STD_LOGIC_VECTOR(31 downto 0);
	signal BUS_Spectrum_1_W_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal BUS_Spectrum_1_R_INT : STD_LOGIC_VECTOR(0 downto 0);
	signal INT_Spectrum_1_STATUS_RD : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_1_CONFIG_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_1_CONFIG_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_1_CONFIG_LIMIT_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_1_CONFIG_LIMIT_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_1_CONFIG_REBIN_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_1_CONFIG_REBIN_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_1_CONFIG_MIN_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_1_CONFIG_MIN_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_Spectrum_1_CONFIG_MAX_WR : STD_LOGIC_VECTOR(31 downto 0);
	signal INT_Spectrum_1_CONFIG_MAX_WR : STD_LOGIC_VECTOR(0 downto 0);
	signal REG_T_OFFSET_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_OFFSET_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_OFFSET_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_OFFSET_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_THRS_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_THRS_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_THRS_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_THRS_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_TRIG_K_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_TRIG_K_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_TRIG_K_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_TRIG_K_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_TRIG_M_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_TRIG_M_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_TRIG_M_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_TRIG_M_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_TRAP_K_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_TRAP_K_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_TRAP_K_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_TRAP_K_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_DECONV_M_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_DECONV_M_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_DECONV_M_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_DECONV_M_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_TRAP_GAIN_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_TRAP_GAIN_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_TRAP_GAIN_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_TRAP_GAIN_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_BL_LEN_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_BL_LEN_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_BL_LEN_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_BL_LEN_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_BL_INIB_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_BL_INIB_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_BL_INIB_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_BL_INIB_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_SAMPLE_POS_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_SAMPLE_POS_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_SAMPLE_POS_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_SAMPLE_POS_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_RUN_CFG_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_RUN_CFG_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_RUN_CFG_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_RUN_CFG_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_T_TRAP_M_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_T_TRAP_M_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_T_TRAP_M_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_T_TRAP_M_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_LENGTH_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_LENGTH_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_LENGTH_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_LENGTH_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_DLENGTH_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_DLENGTH_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_DLENGTH_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_DLENGTH_RD : STD_LOGIC_VECTOR(0 downto 0); 
	signal REG_MODE_RD : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal REG_MODE_WR : STD_LOGIC_VECTOR(31 downto 0) := x"00000000"; 
	signal INT_MODE_WR : STD_LOGIC_VECTOR(0 downto 0); 
	signal INT_MODE_RD : STD_LOGIC_VECTOR(0 downto 0); 

	
begin
	CHA0 <= ADC_A_IN;
	CHA1 <= ADC_B_IN;

	Inst_ftdi245_cdc: ftdi245_cdc PORT MAP(
		FTDI_ADBUS => FTDI_ADBUS,
		FTDI_RXFN => FTDI_RXFN,
		FTDI_TXEN => FTDI_TXEN,
		FTDI_RDN => FTDI_RDN,
		FTDI_TXN => FTDI_TXN,
		FTDI_CLK => FTDI_CLK,
		FTDI_OEN => FTDI_OEN,
		FTDI_SIWU => FTDI_SIWU,
		f_CLK => sample_clk ,
		f_RESET => '0',
		
	    EEMOSI => EEMOSI,
        EEMISO => EEMISO,
        EECLK => EECLK,
        EECS => EECS,

		
		-- Register interface  
			BUS_Spectrum_0_READ_ADDRESS => BUS_Spectrum_0_READ_ADDRESS,
	BUS_Spectrum_0_READ_DATA => BUS_Spectrum_0_READ_DATA,
	BUS_Spectrum_0_WRITE_DATA => BUS_Spectrum_0_WRITE_DATA,
	BUS_Spectrum_0_W_INT => BUS_Spectrum_0_W_INT,
	BUS_Spectrum_0_R_INT => BUS_Spectrum_0_R_INT,
	BUS_Spectrum_0_VLD => BUS_Spectrum_0_VLD,
		REG_Spectrum_0_STATUS_RD => REG_Spectrum_0_STATUS_RD,
		INT_Spectrum_0_STATUS_RD => INT_Spectrum_0_STATUS_RD,
		REG_Spectrum_0_CONFIG_WR => REG_Spectrum_0_CONFIG_WR,
		INT_Spectrum_0_CONFIG_WR => INT_Spectrum_0_CONFIG_WR,
		REG_Spectrum_0_CONFIG_RD => REG_Spectrum_0_CONFIG_WR,
		REG_Spectrum_0_CONFIG_LIMIT_WR => REG_Spectrum_0_CONFIG_LIMIT_WR,
		INT_Spectrum_0_CONFIG_LIMIT_WR => INT_Spectrum_0_CONFIG_LIMIT_WR,
		REG_Spectrum_0_CONFIG_LIMIT_RD => REG_Spectrum_0_CONFIG_LIMIT_WR,
		REG_Spectrum_0_CONFIG_REBIN_WR => REG_Spectrum_0_CONFIG_REBIN_WR,
		INT_Spectrum_0_CONFIG_REBIN_WR => INT_Spectrum_0_CONFIG_REBIN_WR,
		REG_Spectrum_0_CONFIG_REBIN_RD => REG_Spectrum_0_CONFIG_REBIN_WR,
		REG_Spectrum_0_CONFIG_MIN_WR => REG_Spectrum_0_CONFIG_MIN_WR,
		INT_Spectrum_0_CONFIG_MIN_WR => INT_Spectrum_0_CONFIG_MIN_WR,
		REG_Spectrum_0_CONFIG_MIN_RD => REG_Spectrum_0_CONFIG_MIN_WR,
		REG_Spectrum_0_CONFIG_MAX_WR => REG_Spectrum_0_CONFIG_MAX_WR,
		INT_Spectrum_0_CONFIG_MAX_WR => INT_Spectrum_0_CONFIG_MAX_WR,
		REG_Spectrum_0_CONFIG_MAX_RD => REG_Spectrum_0_CONFIG_MAX_WR,
		REG_T_OFFSET_RD => REG_T_OFFSET_RD,
		REG_T_OFFSET_WR => REG_T_OFFSET_WR,
		INT_T_OFFSET_RD => INT_T_OFFSET_RD,
		INT_T_OFFSET_WR => INT_T_OFFSET_WR,
		REG_T_THRS_RD => REG_T_THRS_RD,
		REG_T_THRS_WR => REG_T_THRS_WR,
		INT_T_THRS_RD => INT_T_THRS_RD,
		INT_T_THRS_WR => INT_T_THRS_WR,
		REG_T_TRIG_K_RD => REG_T_TRIG_K_RD,
		REG_T_TRIG_K_WR => REG_T_TRIG_K_WR,
		INT_T_TRIG_K_RD => INT_T_TRIG_K_RD,
		INT_T_TRIG_K_WR => INT_T_TRIG_K_WR,
		REG_T_TRIG_M_RD => REG_T_TRIG_M_RD,
		REG_T_TRIG_M_WR => REG_T_TRIG_M_WR,
		INT_T_TRIG_M_RD => INT_T_TRIG_M_RD,
		INT_T_TRIG_M_WR => INT_T_TRIG_M_WR,
		REG_T_TRAP_K_RD => REG_T_TRAP_K_RD,
		REG_T_TRAP_K_WR => REG_T_TRAP_K_WR,
		INT_T_TRAP_K_RD => INT_T_TRAP_K_RD,
		INT_T_TRAP_K_WR => INT_T_TRAP_K_WR,
		REG_T_DECONV_M_RD => REG_T_DECONV_M_RD,
		REG_T_DECONV_M_WR => REG_T_DECONV_M_WR,
		INT_T_DECONV_M_RD => INT_T_DECONV_M_RD,
		INT_T_DECONV_M_WR => INT_T_DECONV_M_WR,
		REG_T_TRAP_GAIN_RD => REG_T_TRAP_GAIN_RD,
		REG_T_TRAP_GAIN_WR => REG_T_TRAP_GAIN_WR,
		INT_T_TRAP_GAIN_RD => INT_T_TRAP_GAIN_RD,
		INT_T_TRAP_GAIN_WR => INT_T_TRAP_GAIN_WR,
		REG_T_BL_LEN_RD => REG_T_BL_LEN_RD,
		REG_T_BL_LEN_WR => REG_T_BL_LEN_WR,
		INT_T_BL_LEN_RD => INT_T_BL_LEN_RD,
		INT_T_BL_LEN_WR => INT_T_BL_LEN_WR,
		REG_T_BL_INIB_RD => REG_T_BL_INIB_RD,
		REG_T_BL_INIB_WR => REG_T_BL_INIB_WR,
		INT_T_BL_INIB_RD => INT_T_BL_INIB_RD,
		INT_T_BL_INIB_WR => INT_T_BL_INIB_WR,
		REG_T_SAMPLE_POS_RD => REG_T_SAMPLE_POS_RD,
		REG_T_SAMPLE_POS_WR => REG_T_SAMPLE_POS_WR,
		INT_T_SAMPLE_POS_RD => INT_T_SAMPLE_POS_RD,
		INT_T_SAMPLE_POS_WR => INT_T_SAMPLE_POS_WR,
		REG_T_RUN_CFG_RD => REG_T_RUN_CFG_RD,
		REG_T_RUN_CFG_WR => REG_T_RUN_CFG_WR,
		INT_T_RUN_CFG_RD => INT_T_RUN_CFG_RD,
		INT_T_RUN_CFG_WR => INT_T_RUN_CFG_WR,
	BUS_Oscilloscope_0_READ_ADDRESS => BUS_Oscilloscope_0_READ_ADDRESS,
	BUS_Oscilloscope_0_READ_DATA => BUS_Oscilloscope_0_READ_DATA,
	BUS_Oscilloscope_0_WRITE_DATA => BUS_Oscilloscope_0_WRITE_DATA,
	BUS_Oscilloscope_0_W_INT => BUS_Oscilloscope_0_W_INT,
	BUS_Oscilloscope_0_R_INT => BUS_Oscilloscope_0_R_INT,
	BUS_Oscilloscope_0_VLD => BUS_Oscilloscope_0_VLD,
		REG_Oscilloscope_0_READ_STATUS_RD => REG_Oscilloscope_0_READ_STATUS_RD,
		INT_Oscilloscope_0_READ_STATUS_RD => INT_Oscilloscope_0_READ_STATUS_RD,
		REG_Oscilloscope_0_READ_POSITION_RD => REG_Oscilloscope_0_READ_POSITION_RD,
		INT_Oscilloscope_0_READ_POSITION_RD => INT_Oscilloscope_0_READ_POSITION_RD,
		REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR => REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR,
		INT_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR => INT_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR,
		REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_RD => REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR,
		REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR => REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR,
		INT_Oscilloscope_0_CONFIG_PRETRIGGER_WR => INT_Oscilloscope_0_CONFIG_PRETRIGGER_WR,
		REG_Oscilloscope_0_CONFIG_PRETRIGGER_RD => REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR,
		REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR => REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR,
		INT_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR => INT_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR,
		REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_RD => REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR,
		REG_Oscilloscope_0_CONFIG_ARM_WR => REG_Oscilloscope_0_CONFIG_ARM_WR,
		INT_Oscilloscope_0_CONFIG_ARM_WR => INT_Oscilloscope_0_CONFIG_ARM_WR,
		REG_Oscilloscope_0_CONFIG_ARM_RD => REG_Oscilloscope_0_CONFIG_ARM_WR,
		REG_Oscilloscope_0_CONFIG_DECIMATOR_WR => REG_Oscilloscope_0_CONFIG_DECIMATOR_WR,
		INT_Oscilloscope_0_CONFIG_DECIMATOR_WR => INT_Oscilloscope_0_CONFIG_DECIMATOR_WR,
		REG_Oscilloscope_0_CONFIG_DECIMATOR_RD => REG_Oscilloscope_0_CONFIG_DECIMATOR_WR,
		REG_T_TRAP_M_RD => REG_T_TRAP_M_RD,
		REG_T_TRAP_M_WR => REG_T_TRAP_M_WR,
		INT_T_TRAP_M_RD => INT_T_TRAP_M_RD,
		INT_T_TRAP_M_WR => INT_T_TRAP_M_WR,
		REG_LENGTH_RD => REG_LENGTH_RD,
		REG_LENGTH_WR => REG_LENGTH_WR,
		INT_LENGTH_RD => INT_LENGTH_RD,
		INT_LENGTH_WR => INT_LENGTH_WR,
		REG_DLENGTH_RD => REG_DLENGTH_RD,
		REG_DLENGTH_WR => REG_DLENGTH_WR,
		INT_DLENGTH_RD => INT_DLENGTH_RD,
		INT_DLENGTH_WR => INT_DLENGTH_WR,
	BUS_Spectrum_1_READ_ADDRESS => BUS_Spectrum_1_READ_ADDRESS,
	BUS_Spectrum_1_READ_DATA => BUS_Spectrum_1_READ_DATA,
	BUS_Spectrum_1_WRITE_DATA => BUS_Spectrum_1_WRITE_DATA,
	BUS_Spectrum_1_W_INT => BUS_Spectrum_1_W_INT,
	BUS_Spectrum_1_R_INT => BUS_Spectrum_1_R_INT,
	BUS_Spectrum_1_VLD => BUS_Spectrum_1_VLD,
		REG_Spectrum_1_STATUS_RD => REG_Spectrum_1_STATUS_RD,
		INT_Spectrum_1_STATUS_RD => INT_Spectrum_1_STATUS_RD,
		REG_Spectrum_1_CONFIG_WR => REG_Spectrum_1_CONFIG_WR,
		INT_Spectrum_1_CONFIG_WR => INT_Spectrum_1_CONFIG_WR,
		REG_Spectrum_1_CONFIG_RD => REG_Spectrum_1_CONFIG_WR,
		REG_Spectrum_1_CONFIG_LIMIT_WR => REG_Spectrum_1_CONFIG_LIMIT_WR,
		INT_Spectrum_1_CONFIG_LIMIT_WR => INT_Spectrum_1_CONFIG_LIMIT_WR,
		REG_Spectrum_1_CONFIG_LIMIT_RD => REG_Spectrum_1_CONFIG_LIMIT_WR,
		REG_Spectrum_1_CONFIG_REBIN_WR => REG_Spectrum_1_CONFIG_REBIN_WR,
		INT_Spectrum_1_CONFIG_REBIN_WR => INT_Spectrum_1_CONFIG_REBIN_WR,
		REG_Spectrum_1_CONFIG_REBIN_RD => REG_Spectrum_1_CONFIG_REBIN_WR,
		REG_Spectrum_1_CONFIG_MIN_WR => REG_Spectrum_1_CONFIG_MIN_WR,
		INT_Spectrum_1_CONFIG_MIN_WR => INT_Spectrum_1_CONFIG_MIN_WR,
		REG_Spectrum_1_CONFIG_MIN_RD => REG_Spectrum_1_CONFIG_MIN_WR,
		REG_Spectrum_1_CONFIG_MAX_WR => REG_Spectrum_1_CONFIG_MAX_WR,
		INT_Spectrum_1_CONFIG_MAX_WR => INT_Spectrum_1_CONFIG_MAX_WR,
		REG_Spectrum_1_CONFIG_MAX_RD => REG_Spectrum_1_CONFIG_MAX_WR,
		REG_MODE_RD => REG_MODE_RD,
		REG_MODE_WR => REG_MODE_WR,
		INT_MODE_RD => INT_MODE_RD,
		INT_MODE_WR => INT_MODE_WR,
		REG_UNIQUE_RD => x"1E20F708",
		REG_UNIQUE_WR => open,
   
        
        REG_FIRMWARE_BUILD => x"12345678",
        
        REG_OFFSET_RD =>REG_OFFSET,
        REG_OFFSET_WR =>REG_OFFSET,
        INT_OFFSET_RD => open,
        INT_OFFSET_WR => REG_OFFSET_WR,

        REG_IO_RD => REG_IO_RD,
        REG_IO_WR => REG_IO_WR,
        INT_IO_RD => open,
        INT_IO_WR => open,
		
      --FLASH CONTROLLER
        BUS_Flash_0_READ_DATA => BUS_Flash_0_READ_DATA,
        BUS_Flash_0_ADDRESS => BUS_Flash_0_ADDRESS, 
        BUS_Flash_0_WRITE_DATA => BUS_Flash_0_WRITE_DATA, 
        BUS_Flash_0_W_INT => BUS_Flash_0_W_INT, 
        BUS_Flash_0_R_INT => BUS_Flash_0_R_INT, 
        BUS_Flash_0_VLD => BUS_Flash_0_VLD, 
        
        REG_FLASH_CNTR_RD => REG_FLASH_CNTR_RD, 
        REG_FLASH_CNTR_WR => REG_FLASH_CNTR_WR, 
        INT_FLASH_CNTR_RD => INT_FLASH_CNTR_RD, 
        INT_FLASH_CNTR_WR => INT_FLASH_CNTR_WR, 
        
        REG_FLASH_ADDRESS_RD => REG_FLASH_ADDRESS_RD, 
        REG_FLASH_ADDRESS_WR => REG_FLASH_ADDRESS_WR, 
        INT_FLASH_ADDRESS_RD => INT_FLASH_ADDRESS_RD, 
        INT_FLASH_ADDRESS_WR => INT_FLASH_ADDRESS_WR,     
        
        -- Test 
        BUS_Test_0_READ_DATA => BUS_Test_0_READ_DATA,
        BUS_Test_0_ADDRESS => BUS_Test_0_ADDRESS, 
        BUS_Test_0_WRITE_DATA => BUS_Test_0_WRITE_DATA, 
        BUS_Test_0_W_INT => BUS_Test_0_W_INT, 
        BUS_Test_0_R_INT => BUS_Test_0_R_INT, 
        BUS_Test_0_VLD => BUS_Test_0_VLD		
        		
	);
	async_clk(0) <= sample_clk;
	CLK_ACQ(0) <= sample_clk;
	GlobalClock(0) <= sample_clk;
	BUS_CLK(0) <= sample_clk;
	boot_led <= power_led_sig;--REG_IO_WR(2);
	lemo_oe <= '0';
	REG_IO_RD(0) <= boot_sw;
	REG_IO_RD(1) <= sw1;
	
	gpio <= REG_IO_WR(15 downto 8);
		
	pwled : process(sample_clk)
	begin
		if rising_edge(sample_clk) then
			if pw_led_counter = 65000000 then
				pw_led_counter <= 0;
				power_led_sig <= '1';
			else
				if pw_led_counter = 6500000 then
					power_led_sig <= '0';
				end if;
				pw_led_counter <= pw_led_counter +1;
			end if;
		end if;
	end process;
	
   LEMO0_BUFF : IOBUF
   generic map (
      DRIVE => 12,
      IOSTANDARD => "DEFAULT",
      SLEW => "SLOW")
   port map (
      O =>  LEMO_0_A_OUT(0),     
      IO => lemo_a,   
      I =>  LEMO_0_A_IN(0),
      T =>  LEMO_0_DIRECTION(0) 
   ); 
   	lemo_dir_a <= LEMO_0_DIRECTION(0);
	
   LEMO2_BUFF : IOBUF
   generic map (
      DRIVE => 12,
      IOSTANDARD => "DEFAULT",
      SLEW => "SLOW")
   port map (
      O =>  LEMO_1_A_OUT(0),     
      IO => lemo_b,   
      I =>  LEMO_1_A_IN(0),
      T =>  LEMO_1_DIRECTION(0) 
   ); 
   	lemo_dir_b <= LEMO_1_DIRECTION(0);	
	
    mcg : main_clk_gen
    port map
    (
        sample_clk => sample_clk,
        locked => mcg_lock,
        clk_in1 => clk_100,
		clk_out2 => open
    );
    
    clk125 : CLK_125MHZ
      PORT MAP(
          clk_out1    => clk_125(0),
          clk_in1    => clk_100
      );
	FAST_CLK_100(0) <= clk_100;

    Inst_scidk_internal_i2c_manager : scidk_internal_i2c_manager 
    Port map( clk => sample_clk,
           reset => GlobalReset(0),
           offset => REG_OFFSET(15 downto 0),
           w_offset => REG_OFFSET_WR(0), 
           sda => IIC_0_sda,
           scl => IIC_0_scl
           );
  
    
    CLK_TO_ADC_A<=sample_clk;
    CLK_TO_ADC_B<=sample_clk;
    GlobalReset(0) <= not mcg_lock;
    SHND_ADC_A <='0';
    SHND_ADC_B <='0';
    OE_ADC_A <= '0';
    OE_ADC_B <= '0';
    


	
	
	U0 : mcahp_test_KHCTRIYF
	PORT MAP(
		adc_data => U1_A0,
		positive_r => U17_CONST(0),
		digital_offset => U2_out_0,
		threshold => U3_out_0,
		trig_k => U4_out_0,
		trig_m => U5_out_0,
		e_k => U16_out_0,
		e_m => U19_out_0,
		e_MDec => U6_out_0,
		e_G => U7_out_0,
		baseline_len => U8_out_0,
		baseline_inib => U9_out_0,
		e_sample_delay => U10_out_0,
		timetag => x"0000000000000000",
		run_cfg => U18_out_0(0),
		tr_reset => '0',
		gin => '0',
		GIN_SELECT => x"0",
		adc_data_out => U0_DATA_OUT,
		energy => U0_ENERGY,
		energy_strobe => U0_ENERGY_STROBE(0),
		trigger_sig => U0_TRIGGER_OUT(0),
		baseline_hold => U0_BASELINE_HOLD(0),
		trigger_delta_monitor => U0_TRIGGER_DELTA_MON,
		trigger_trap_monitor => U0_TRIGGER_TRAP_MON,
		trap => U0_TRAP_MON,
		trap_minus_baseline => U0_TRAP_BL_MON,
		baseline_out => U0_BL_MON,
		timestamp => open,
		tr_inhibit_trigger => open,
		ap_clk => CLK_ACQ(0),
		ap_rst => GlobalReset(0)
	);

U1_A0 <= "0000" & CHA0(13 downto 2);
U2_out_0 <= REG_T_OFFSET_WR(15 downto 0);
REG_T_OFFSET_RD  <= REG_T_OFFSET_WR;
U3_out_0 <= REG_T_THRS_WR(31 downto 0);
REG_T_THRS_RD  <= REG_T_THRS_WR;
U4_out_0 <= REG_T_TRIG_K_WR(15 downto 0);
REG_T_TRIG_K_RD  <= REG_T_TRIG_K_WR;
U5_out_0 <= REG_T_TRIG_M_WR(15 downto 0);
REG_T_TRIG_M_RD  <= REG_T_TRIG_M_WR;
U6_out_0 <= REG_T_DECONV_M_WR(23 downto 0);
REG_T_DECONV_M_RD  <= REG_T_DECONV_M_WR;
U7_out_0 <= REG_T_TRAP_GAIN_WR(23 downto 0);
REG_T_TRAP_GAIN_RD  <= REG_T_TRAP_GAIN_WR;
U8_out_0 <= REG_T_BL_LEN_WR(3 downto 0);
REG_T_BL_LEN_RD  <= REG_T_BL_LEN_WR;
U9_out_0 <= REG_T_BL_INIB_WR(15 downto 0);
REG_T_BL_INIB_RD  <= REG_T_BL_INIB_WR;
U10_out_0 <= REG_T_SAMPLE_POS_WR(15 downto 0);
REG_T_SAMPLE_POS_RD  <= REG_T_SAMPLE_POS_WR;

	U11 : xlx_oscilloscope_sync
	Generic map(
		channels => 	6,
		memLength => 	2048,
		wordWidth => 	28
	)
	PORT MAP(
		ANALOG => U15_b & U14_b & U13_b & U12_b & U22_b & U21_b,
		D0 => "0" & "0" & "0" & "0" & "0" & U0_TRIGGER_OUT,
		D1 => "0" & "0" & "0" & "0" & "0" & U0_BASELINE_HOLD,
		D2 => "0" & "0" & "0" & "0" & "0" & U0_ENERGY_STROBE,
		D3 => "0" & "0" & "0" & "0" & "0" & "0",
		TRIG => "0",
		BUSY => open,
		CE => "1",
		CLK_WRITE => CLK_ACQ,
		RESET => GlobalReset,
		CLK_READ => BUS_CLK,
		READ_ADDRESS => BUS_Oscilloscope_0_READ_ADDRESS,
		READ_DATA => BUS_Oscilloscope_0_READ_DATA,
		READ_DATAVALID => BUS_Oscilloscope_0_VLD,
		READ_STATUS => REG_Oscilloscope_0_READ_STATUS_RD,
		READ_POSITION => REG_Oscilloscope_0_READ_POSITION_RD,
		CONFIG_TRIGGER_MODE => REG_Oscilloscope_0_CONFIG_TRIGGER_MODE_WR,
		CONFIG_TRIGGER_LEVEL => REG_Oscilloscope_0_CONFIG_TRIGGER_LEVEL_WR,
		CONFIG_PRETRIGGER => REG_Oscilloscope_0_CONFIG_PRETRIGGER_WR,
		CONFIG_DECIMATOR => REG_Oscilloscope_0_CONFIG_DECIMATOR_WR,
		CONFIG_ARM => REG_Oscilloscope_0_CONFIG_ARM_WR
	);


	U12 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	28,
		OPERATION => 	"sign_to_sign"
	)
	PORT MAP(
		a => U0_TRIGGER_TRAP_MON,
		b => U12_b
	);


	U13 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	28,
		OPERATION => 	"sign_to_sign"
	)
	PORT MAP(
		a => U0_TRAP_MON,
		b => U13_b
	);


	U14 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	28,
		OPERATION => 	"sign_to_sign"
	)
	PORT MAP(
		a => U0_TRAP_BL_MON,
		b => U14_b
	);


	U15 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	28,
		OPERATION => 	"sign_to_sign"
	)
	PORT MAP(
		a => U0_BL_MON,
		b => U15_b
	);

U16_out_0 <= REG_T_TRAP_K_WR(15 downto 0);
REG_T_TRAP_K_RD  <= REG_T_TRAP_K_WR;
U17_CONST <= conv_std_logic_vector(1,1);
U18_out_0 <= REG_T_RUN_CFG_WR(0 downto 0);
REG_T_RUN_CFG_RD  <= REG_T_RUN_CFG_WR;
U19_out_0 <= REG_T_TRAP_M_WR(15 downto 0);
REG_T_TRAP_M_RD  <= REG_T_TRAP_M_WR;

	U20 : xlx_spectrum
	Generic map(
		memLength => 	4096,
		wordWidth => 	32,
		CLK_FREQ => 	125000
	)
	PORT MAP(
		ENERGY => U26_EVENT_OUT,
		ENERGY_STROBE => U26_DV_OUT,
		P_running => open,
		P_acceptedPulse => open,
		CLK_WRITE => CLK_ACQ,
		CE => "1",
		RESET => GlobalReset,
		CLK_READ => BUS_CLK,
		READ_ADDRESS => BUS_Spectrum_1_READ_ADDRESS,
		READ_DATA => BUS_Spectrum_1_READ_DATA,
		READ_INT => BUS_Spectrum_1_R_INT,
		READ_DATAVALID => BUS_Spectrum_1_VLD,
		STATUS => REG_Spectrum_1_STATUS_RD,
		CONFIG => REG_Spectrum_1_CONFIG_WR,
		CONFIG_LIMIT => REG_Spectrum_1_CONFIG_LIMIT_WR,
		CONFIG_REBIN => REG_Spectrum_1_CONFIG_REBIN_WR,
		CONFIG_MIN => REG_Spectrum_1_CONFIG_MIN_WR,
		CONFIG_MAX => REG_Spectrum_1_CONFIG_MAX_WR
	);


	U21 : sigunsig
	Generic map(
		A_SIZE => 	16,
		B_SIZE => 	28,
		OPERATION => 	"unsign_to_sign"
	)
	PORT MAP(
		a => U0_DATA_OUT,
		b => U21_b
	);


	U22 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	28,
		OPERATION => 	"sign_to_sign"
	)
	PORT MAP(
		a => U0_TRIGGER_DELTA_MON,
		b => U22_b
	);


	U23 : sigunsig
	Generic map(
		A_SIZE => 	32,
		B_SIZE => 	16,
		OPERATION => 	"unsign_to_sign"
	)
	PORT MAP(
		a => U0_ENERGY,
		b => U23_b
	);

U24_out_0 <= REG_LENGTH_WR(31 downto 0);
REG_LENGTH_RD  <= REG_LENGTH_WR;
U25_out_0 <= REG_DLENGTH_WR(31 downto 0);
REG_DLENGTH_RD  <= REG_DLENGTH_WR;

	U26 : PileupRejector_PFPWEZES
	PORT MAP(
		data_in => U23_b,
		dv_in => U0_ENERGY_STROBE(0),
		pileup_inib_double => U25_out_0,
		pileup_inib => U24_out_0,
		mode => U27_out_0,
		prarallizable => '1',
		rst_stat => '0',
		ap_clk => CLK_ACQ(0),
		ap_rst => GlobalReset(0),
		data_out => U26_EVENT_OUT,
		dv_out => U26_DV_OUT(0),
		inib => open,
		rej => open,
		drej => open,
		ic => open,
		oc => open,
		rejected => open,
		rejected_double => open
	);

U27_out_0 <= REG_MODE_WR(3 downto 0);
REG_MODE_RD  <= REG_MODE_WR;

		 
end Behavioral;

 